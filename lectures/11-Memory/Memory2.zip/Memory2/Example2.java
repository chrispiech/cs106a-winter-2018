
import acm.program.*;
import acm.graphics.*;
import acm.util.*;
import java.awt.*;
import java.awt.event.*;

public class Example2 extends ConsoleProgram {
	

	public void run() {
		// this line just makes the font large
		setFont("Courier-24");
		
		int first = 5;
		int second = 5;
		println(first == second);
	}
}

