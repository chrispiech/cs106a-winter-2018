
import acm.program.*;
import acm.graphics.*;
import acm.util.*;
import java.awt.*;
import java.awt.event.*;

public class Example3 extends ConsoleProgram {


	public void run() {
		// this line just makes the font large
		setFont("Courier-24");

		int x = 2;
		addFive(x);
		println(x);
	}

	private void addFive(int x) {
		x += 5;
	}


}

