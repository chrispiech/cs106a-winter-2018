
import acm.program.*;
import acm.graphics.*;
import acm.util.*;
import java.awt.*;
import java.awt.event.*;

public class Tsa extends GraphicsProgram {
	
	// this variable can make random numbers
	private RandomGenerator rg = new RandomGenerator();
	
	// this program is worth at least $50,000
	public void run() {
		
		while(true) {
			boolean isLeft = rg.nextBoolean();
			if(isLeft) {
				showLeftArrow();
			} else {
				showRightArrow();
			}
			waitForClick();
			removeAll();
			pause(500);
		}
	}

	// displays a centered right arrow img
	private void showRightArrow() {
		GImage leftArrow = new GImage("leftArrow.png");
		addImgCentered(leftArrow);
	}

	// displays a centered left arrow img
	private void showLeftArrow() {
		GImage rightArrow = new GImage("rightArrow.png");
		addImgCentered(rightArrow);
	}

	// takes an image and adds it to the screen
	private void addImgCentered(GImage img) {
		double w = img.getWidth();
		double h = img.getHeight();
		double x = (getWidth() - w) / 2;
		double y = (getHeight() - h) / 2;
		add(img, x, y);
	}
}

