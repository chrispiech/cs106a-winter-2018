/*
 * File: DribbleCastle.java
 * ================================================================
 * A program that simulates building of a dribble castle which is
 * made by dropping sand one dribble at a time.
 */
import acm.program.*;
import acm.graphics.*;
import acm.util.*;
import java.awt.*;
import java.awt.event.*;

public class UFO extends GraphicsProgram {

	/** Size and speed of UFO */
	private static final int UFO_WIDTH = 40;
	private static final int UFO_HEIGHT = UFO_WIDTH / 2;
	private static final int UFO_SPEED = 5;

	/** Size and speed of bullets */
	private static final int BULLET_SPEED = 10;
	private static final int BULLET_DIAM = 5;

	/** Animation cycle delay */
	private static final int DELAY = 5;

	/* private instance variables */
	private GRect ufo = null;
	private boolean isUfoMovingLeft = false;
	private GOval bullet = null;

	public void run() {
		setup();
		addMouseListeners();
		while(true) {
			//update 
			moveUfo();
			moveBullet();

			// animation loop pause
			pause(DELAY);
		}
	}

	// when a mouse is pressed, fire a bullet
	public void mousePressed(MouseEvent e) {
		// if bullet != null, there is a live bullet
		if(bullet == null) {
			bullet = new GOval(BULLET_DIAM, BULLET_DIAM);
			bullet.setFilled(true);
			add(bullet, getWidth() / 2, getHeight());
		}
	}

	// moves the bullet for one heartbeat of animation
	private void moveBullet() {
		// if there is no bullet, don't animate it
		if(bullet != null) {
			bullet.move(0, -BULLET_SPEED);
			if(bullet.getY() < 0) {
				// if the bullet is off the screen, remove it
				remove(bullet);
				// and set bullet to be null (so we know its gone)
				bullet = null;
			}
		}

	}

	// move the ufo for one heartbeat of animation
	private void moveUfo() {
		// move the UFO right or left
		if(!isUfoMovingLeft) {
			ufo.move(UFO_SPEED, 0);
		} else {
			ufo.move(-UFO_SPEED, 0);
		}

		// bounce the UFO off of any walls
		if(ufo.getX() > getWidth() - UFO_WIDTH) {
			isUfoMovingLeft = true;
			ufo.move(0, UFO_HEIGHT);
		}
		if(ufo.getX() < 0) {
			isUfoMovingLeft = false;
			ufo.move(0, UFO_HEIGHT);
		}
	}

	// creates the ufo and adds it to the screen!
	private void setup() {
		ufo = new GRect(UFO_WIDTH, UFO_HEIGHT);
		ufo.setColor(Color.RED);
		ufo.setFilled(true);
		add(ufo);
	}

}