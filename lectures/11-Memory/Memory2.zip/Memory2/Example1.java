
import acm.program.*;
import acm.graphics.*;
import acm.util.*;
import java.awt.*;
import java.awt.event.*;

public class Example1 extends ConsoleProgram {


	public void run() {
		// this line just makes the font large
		setFont("Courier-24");

		GRect first = new GRect(20, 30);
		GRect second = new GRect(20, 30);
		println(first == second);
	}
}

