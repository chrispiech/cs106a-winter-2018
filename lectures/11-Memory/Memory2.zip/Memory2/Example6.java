
import acm.program.*;
import acm.graphics.*;
import acm.util.*;
import java.awt.*;
import java.awt.event.*;

public class Example6 extends GraphicsProgram {
	
	// this only stores a single address (or null)
	private GRect brick = null;
	
	public void update() {
		GObject collider = getCollidingObject();
		if(collider == brick) {
			remove(brick);
		}
	}
	
	private GObject getCollidingObject() {
		return null;
	}
}

