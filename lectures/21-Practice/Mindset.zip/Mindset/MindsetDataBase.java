
import acm.util.*;
import java.util.*;

public class MindsetDataBase implements MindsetConstants {
	
	// a ton of countries
	
	
/* Constructor: MindsetDatabase() */
	public MindsetDataBase() {
		// You fill this in //
	}
	
/* Method: findEntry(name) */
	public Country findEntry(String name) {
		// You need to turn this stub into a real implementation //
		return null;
	}

	public void loadYourself() {
		// TODO Auto-generated method stub
		
	}

	public ArrayList<String> getAllCountryNames() {
		// TODO Auto-generated method stub
		return null;
	}
}

