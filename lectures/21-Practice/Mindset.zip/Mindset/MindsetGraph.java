

import acm.graphics.*;
import java.awt.event.*;
import java.util.*;
import java.awt.*;

public class MindsetGraph extends GCanvas implements MindsetConstants {

	public MindsetGraph() {
	}

	public void setupAxis() {
		// TODO Auto-generated method stub	
	}

	public void clearBubbles() {
		// TODO Auto-generated method stub
		
	}

	public void addBubble(double x, double y, String countryName) {
		// TODO Auto-generated method stub
		
	}
	
	
}
