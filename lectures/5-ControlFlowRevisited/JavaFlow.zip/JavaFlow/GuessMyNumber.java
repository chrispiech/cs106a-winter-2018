/*
 * File: PythagoreanTheorem.java
 * Name: 
 * Section Leader: 
 * -----------------------------
 * This file is the starter file for the PythagoreanTheorem problem.
 */

import acm.program.*;

public class GuessMyNumber extends ConsoleProgram {

	public void run() {	
		setFont("Courier-24");
		int secretNumber = getHeight() % 100;
		println("I am thinking of a number between 0 and 99...");
		

	}

}
