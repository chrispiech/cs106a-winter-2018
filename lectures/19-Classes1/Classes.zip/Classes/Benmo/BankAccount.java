import java.awt.Color;

import acm.graphics.GOval;
import acm.util.RandomGenerator;

public class BankAccount {
	
	
	// 1: what variables make up a bank account?
	public double money;
	public String name;
	
	
}
