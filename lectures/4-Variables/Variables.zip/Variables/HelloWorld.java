/*
 * File: HelloWorld.java
 * Name: 
 * Section Leader: 
 * -----------------------------
 * This file is the starter file for the PythagoreanTheorem problem.
 */

import acm.program.*;

public class HelloWorld extends ConsoleProgram {
	
	// The program starts here
	public void run() {
		println("Hello, world");
	}
	
}
