/*
 * File: Restaurant.java
 * --------------------
 * After the user enters the original cost of a meal, we add
 * 8% tax and 20% tip.
 */

import acm.program.*;

public class Restaurant extends ConsoleProgram {


	public void run() {
		
		
	}



	
	
	
	
	
	
	
	










	/**
	 * Method: Init
	 * ------------
	 * This is some special code I added so that the font in
	 * the programs is larger. You can ignore it, and you don't
	 * need an init in your programs!
	 */
	public void init() {
		// used to make the font visible in lecture...
		setFont("Courier-24");
	}
}

