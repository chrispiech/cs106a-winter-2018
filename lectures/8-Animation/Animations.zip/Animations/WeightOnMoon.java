/*
 * File: WeightOnMoon.java
 * --------------------
 * A tool to turn earth weight into moon weight.
 */

import acm.program.*;

public class WeightOnMoon extends ConsoleProgram {

	public void run() {
		// Folks in the back, this is for you!
		setFont("Courier-24");

	}
	
	
	
}

