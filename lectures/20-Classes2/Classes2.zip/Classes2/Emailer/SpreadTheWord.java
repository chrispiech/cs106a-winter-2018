/*
 * File: BlankClass.java
 * ---------------------
 * This class is a blank one that you can change at will. Remember, if you change
 * the class name, you'll need to change the filename so that it matches.
 * Then you can extend GraphicsProgram, ConsoleProgram, or DialogProgram as you like.
 */

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import acm.program.*;
import acm.util.RandomGenerator;

public class SpreadTheWord extends ConsoleProgram {

	// number of students to include in the email
	private static final int N_STUDENTS_IN_EMAIL = 5;

	// send those emails!
	public void run() {
		runTest();
	}

	// sends a single email to chrisjpiech.test
	private void runTest() {
		Email email = new Email("chrisjpiech.test@gmail.com", "hello world");
		email.setBody(generateSocialEmailText());
		email.send();
	}

	// makes the body for our little experiment
	private String generateSocialEmailText() {
		// generate text for the email
		String body = "";
		body += "Dear Unknown,\n\n";
		body += "I hope this email finds you well.\n\n";
		body += "As you know, CS106A is a huge class with many wonderful people in it. ";
		body += "In lecture today we built a program to help you meet a few fellow students. ";
		body += "Here are five random people in CS106A. ";
		body += "You can (optionally) introduce yourself:\n";

		body += "\n";
		body += "All the best,\n";
		body += "Chris";
		body += "\n\n";
		body += "P.S. Today we covered 'classes' which introduces a whole new way of thinking about programs";
		return body;
	}


	// load all students from the file students.csv
	private void loadEmails() {
		try {
			Scanner sc = new Scanner(new File("students.csv"));
			while(sc.hasNextLine()) {
				String line = sc.nextLine();
				String[] cols = line.split(",");
				String name = cols[0];
				String address = cols[1];
				
				// TODO: your code here
			}
			sc.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}

