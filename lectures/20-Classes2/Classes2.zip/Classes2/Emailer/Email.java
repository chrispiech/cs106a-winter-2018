
public class Email {

	// this is how you make a new email
	public Email(String toAddress, String subject) {
		// TODO: your code here
	}

	// warning: actually sends an email!
	public void send() {
		EmailSender sender = new EmailSender();
		// TODO: your code here
	}
	
	// sets the body of the email
	public void setBody(String newBody) {
		// TODO: your code here
	}

}