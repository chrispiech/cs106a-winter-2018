/*
 * File: WordCount.java
 * --------------------
 * Counts the characters, words, and lines in a file.
 */

import acm.program.*;
import java.io.*;
import java.util.*;

public class WordCount extends ConsoleProgram {	

	public void run() {
		int lines = 0;
		int words = 0;
		int chars = 0;
		Scanner fileScanner = openScanner("File: ");
		while (fileScanner.hasNextLine()) {
			String line = fileScanner.nextLine();
			lines++;
			words += countWords(line);
			chars += line.length();
		}
		fileScanner.close();

		println("Lines = " + lines);
		println("Words = " + words);
		println("Chars = " + chars);
	}

	/**
	 * Asks the user for the name of an input file and returns a
	 * Scanner attached to its contents.  If the file does
	 * not exist, the user is reprompted until they enter a valid filename.
	 */ 
	private Scanner openScanner(String prompt) {
		Scanner fileScanner = null;
		while (fileScanner == null) {
			String name = readLine(prompt);
			try {
				fileScanner = new Scanner(new File(name));
			} catch (IOException ex) {
				println("Can't open that file.");
			}
		}
		return fileScanner;
	}

	/**
	 * Counts the words (consecutive strings of letters and/or digits)
	 * in the input line.
	 */ 
	private int countWords(String line) {
		boolean inWord = false;
		int words = 0;
		for (int i = 0; i < line.length(); i++) {
			char ch = line.charAt(i);
			if (Character.isLetterOrDigit(ch)) {
				inWord = true;
			} else {
				if (inWord) {
					words++;
				}
				inWord = false;
			}
		}
		if (inWord) {
			words++;
		}
		return words;
	}
}
