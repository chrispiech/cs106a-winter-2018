/*
 * File: IndexOf.java
 * ----------------------
 * This program is a test program for the index of method in section
 * handout #5, problem 4.  It tests calls to the indexOf method and
 * prints out the results.
 */

import acm.program.*;

public class IndexOf extends ConsoleProgram {
	
	public void run() {
		int[] arr = {42, 7, -9, 14, 8, 39, 42, 8, 19, 0};
		println("indexOf(arr, 8) = " + indexOf(arr, 8)); 	// should be 4
		println("indexOf(arr, 2) = " + indexOf(arr, 2));	// should be -1;
	}
	
	/** This is the required method that finds an element in an array a given array. **/
	private int indexOf(int[] list, int target) {
		for (int i = 0; i < list.length; i++) {
			if (list[i] == target) {
				return i;
			}
		}
		return -1;
	}
}
