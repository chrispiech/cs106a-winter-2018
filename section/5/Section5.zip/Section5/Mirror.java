/*
 * File: Mirror.java
 * ----------------------
 * This program is a test program for the mirror method in section
 * handout #5, problem 3.  It asks the user for ArrayList elements,
 * and then prints out an ArrayList with those items and the mirror
 * of those items.
 */

import acm.program.*;
import java.util.*;

public class Mirror extends ConsoleProgram {
	
	public void run() {
		ArrayList<String> list = new ArrayList<String>();
		while (true) {
			String element = readLine("Enter element: ");
			if (element.equals("")) {
				break;
			}
			list.add(element);
		}

		mirror(list);
		println(list);
	}
	
	/** This is the required method that mirrors a given ArrayList. **/
	private void mirror(ArrayList<String> list) {
		for (int i = list.size() - 1; i >= 0; i--) { 
			list.add(list.get(i));
		} 
	}
}
