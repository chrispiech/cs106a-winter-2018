/*
 * File: Collapse.java
 * ----------------------
 * This program is a test program for the collapse method in section
 * handout #5, problem 6.  It prompts the user to enter a list of
 * numbers, and then prints out the collapsed elements.
 */

import acm.program.*;

public class Collapse extends ConsoleProgram {
	
	public void run() {
		int length = readInt("How many numbers will you enter? ");
		int[] numList = new int[length];
		for (int i = 0; i < numList.length; i++) {
			numList[i] = readInt("#: ");
		}
		
		int[] collapsedList = collapse(numList);
		
		// print out the new array, 1 element at a time
		for (int i = 0; i < collapsedList.length; i++) {
			println(collapsedList[i]);
		}
	}
	
	/**
	 * This is the required method that collapses pairs of elements in an array
	 * by summing them, and returns the resulting array.
	 */
	private int[] collapse(int[] list) {
		int[] result = new int[list.length / 2 + list.length % 2];
		for (int i = 0; i < result.length - list.length % 2; i++) {
			result[i] = list[2 * i] + list[2 * i + 1];
		}
		if (list.length % 2 == 1) {
			result[result.length - 1] = list[list.length - 1];
		}
		return result;
	}

}
