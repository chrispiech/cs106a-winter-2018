import acm.program.*;
import java.util.*;
import java.io.*;

/**
 * This server reads in data about all members of congress,
 * and can respond to "getCongressEmailsForState" and
 * "getCongressPhonesForState" requests.  Both request types
 * should include a "stateCode" parameter. Both send back a string
 * containing a list of all that state's congress members, and their
 * requested information (phone or email).  Note that not all members
 * are guaranteed to have an email address. 
 */
public class ContActivistServer extends ConsoleProgram 
	implements SimpleServerListener {
	
	/* The internet port to listen to requests on */
	private static final int PORT = 8000;
	
	/* The server object. All you need to do is start it */
	private SimpleServer server = new SimpleServer(this, PORT);

	/* The name of the congress member data file */
	private static final String DATA_FILENAME = "congress.txt";

	/* A map from state code to its list of congress members */
	private HashMap<String, ArrayList<CongressMember>> congressMap;

	public void run() {
		congressMap = readCongressFile(DATA_FILENAME);
		println("Starting server on port " + PORT);
		server.start();
	}

	/* Reads in the provided data file of congress members, and
	 * returns a map from state code to a list of its congress
	 * members.
	 */
	private HashMap<String, ArrayList<CongressMember>> readCongressFile(
			String filename) {

		try {
			Scanner scanner = new Scanner(new File(filename));
			
			HashMap<String, ArrayList<CongressMember>> congress 
				= new HashMap<String, ArrayList<CongressMember>>();

			// Read in 5 lines at a time (for each member)
			while (scanner.hasNextLine()) {
				String name = scanner.nextLine();
				String stateCode = scanner.nextLine();
				String phone = scanner.nextLine();
				String email = scanner.nextLine();
				if (email.length() == 0) {
					email = null;
				}

				// Add a new person to our map
				CongressMember member = 
						new CongressMember(name, phone, email);
				if (congress.containsKey(stateCode)) {
					congress.get(stateCode).add(member);
				} else {
					ArrayList<CongressMember> personList = 
							new ArrayList<CongressMember>();
					personList.add(member);
					congress.put(stateCode, personList);
				}

				// For the blank line separating each member
				scanner.nextLine();
			}
			scanner.close();
			return congress;
		} catch (IOException e) {
			println("Error reading data file: " + e);
			return null;
		}
	}

	/* Responds to incoming requests that we receive */
	@Override
	public String requestMade(Request request) {
		String cmd = request.getCommand();
		println(request.toString());
		
		if (cmd.equals("getCongressPhonesForState")) {
			String stateCode = request.getParam("stateCode");
			if (!congressMap.containsKey(stateCode)) {
				return "Error: unknown state " + stateCode;
			}
			
			// Build up the response string of all member information
			String response = "";
			ArrayList<CongressMember> members = congressMap.get(stateCode);
			for (CongressMember member : members) {
				response += member.getPhoneDescription() + "\n";
			}
			return response;
		} else if (cmd.equals("getCongressEmailsForState")) {
			String stateCode = request.getParam("stateCode");
			if (!congressMap.containsKey(stateCode)) {
				return "Error: unknown state " + stateCode;
			}
			
			// Build up the response string of all member information
			String response = "";
			ArrayList<CongressMember> members = congressMap.get(stateCode);
			for (CongressMember member : members) {
				response += member.getEmailDescription() + "\n";
			}
			return response;
		}
		
		return "Error: Unknown command " + cmd + ".";
	}
}

