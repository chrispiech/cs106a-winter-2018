/**
 * This class represents a single representative or senator
 * in Congress, and contains information about them including:
 * name, phone number, and optionally an email address.
 */
public class CongressMember {
	private String name;
	private String phone;
	private String email;
	
	public CongressMember(String name, String phone, String email) {
		this.name = name;
		this.phone = phone;
		this.email = email;
	}
	
	/**
	 * Returns a string description of this person, which
	 * includes their name and phone number.
	 */
	public String getPhoneDescription() {
		return name + ": " + phone;
	}
	
	/**
	 * Returns a string description of this person, which
	 * includes their name, and email if there is one, or
	 * "NO EMAIL" otherwise.
	 */
	public String getEmailDescription() {
		if (email != null) {
			return name + ": " + email;
		} else {
			return name + ": NO EMAIL";
		}
	}
}
