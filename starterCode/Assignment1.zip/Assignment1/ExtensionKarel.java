/*
 * File: ExtensionKarel.java
 * --------------------------------
 * Make something great!
 */

import stanford.karel.*;

public class ExtensionKarel extends SuperKarel {
	
	// You fill in this part
	
}